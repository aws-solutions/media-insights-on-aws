
from __future__ import absolute_import

import subprocess
import sys
import io
import os

import json

import mxnet as mx
import numpy as np
import PIL.Image

# Install GluonCV so we can use the built-in FCNN transformations. 
def install(package):
    subprocess.call([sys.executable, "-m", "pip", "install", package])
    
install("gluoncv")
install("opencv-python")

import gluoncv
import cv2
from gluoncv.data.transforms.pose import detector_to_alpha_pose, heatmap_to_coord_alpha_pose

ctx = mx.gpu(0) if mx.context.num_gpus() > 0 else mx.cpu()
#forcing ctx to be cpu for now because of an error encountered with upscale_bbox not acquring gpu context
#ctx = mx.cpu()
print(ctx)
print("initialize")
# Pre-loading the model on startup and setting autotune to 0 for speed
#pose_net = gluoncv.model_zoo.get_model('alpha_pose_resnet101_v1b_coco', pretrained=True,ctx=ctx)
os.environ["MXNET_CUDNN_AUTOTUNE_DEFAULT"] = "0"

# ------------------------------------------------------------ #
# Hosting methods                                              #
# ------------------------------------------------------------ #

def model_fn(model_dir):
    """
    Load the GluonCV model. Called once when hosting service starts. Model was downloaded on startup.
    :param: model_dir The directory where model files are stored.
    :return: a model (in this case a Gluon network)
    """  
    print("model_fn")
    ctx = mx.gpu(0) if mx.context.num_gpus() > 0 else mx.cpu()
    print(ctx)
    #net = gluoncv.model_zoo.get_model('faster_rcnn_fpn_resnet101_v1d_coco', pretrained=True, ctx=ctx)
    pose_net = gluoncv.model_zoo.get_model('alpha_pose_resnet101_v1b_coco', pretrained=True,ctx=ctx)
    return pose_net


def transform_fn(pose_net, payload, content_type, accept):
    """
    Transform a request using the GluonCV model. Called once per request.
    :param detector: The GluonCV model.
    :param payload: The request payload.
    :param content_type: The input content type.
    :param accept: The (desired) content type.
    :return: response output.
    """
    
    print("transform")
    ctx = mx.gpu(0) if mx.context.num_gpus() > 0 else mx.cpu()
    print(ctx)
    result = json.loads(payload)
    pose_input = mx.nd.array(np.expand_dims(np.asarray(result['pose_input']), axis=0))
    upscale_bbox = mx.nd.array(np.expand_dims(np.asarray(result['upscale_bbox']),axis=0))
    # This section is from the GluonCV tutorial for alpha pose estimation
    predicted_heatmap = pose_net(pose_input.as_in_context(ctx))
    predicted_heatmap = mx.nd.array(predicted_heatmap)
    print("inference")
    print(ctx)
    pred_coords, confidence = heatmap_to_coord_alpha_pose(predicted_heatmap, upscale_bbox)
    
    # Format the response for being passed back from the endpoint
    response = {}
    response['pred_coords'] = pred_coords.asnumpy().tolist()
    response['confidence'] = confidence.asnumpy().tolist()
    #pred_coords = pred_coords[0].asnumpy()
    #confidence = confidence[0].asnumpy().reshape(-1)
    #arbitrary threshold for keypoints confidence based on example from gluon cv tutorial
    #pred_coords = pred_coords[confidence>0.3]
    #confidence = confidence[confidence>0.3]
    #response['pred_coords'] = pred_coords.tolist()
    #response['confidence'] = confidence.tolist()
    output = json.dumps(response)
    
    return output

