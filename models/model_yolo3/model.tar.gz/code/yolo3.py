
from __future__ import absolute_import

import subprocess
import sys
import io
import os

import json

import mxnet as mx
import numpy as np
import PIL.Image

# Install GluonCV so we can use the built-in FCNN transformations. 
def install(package):
    subprocess.call([sys.executable, "-m", "pip", "install", package])
    
install("gluoncv")

install("opencv-python")

import gluoncv
import cv2
from gluoncv.data.transforms.pose import detector_to_alpha_pose

ctx = mx.gpu(0) if mx.context.num_gpus() > 0 else mx.cpu()
print("*****")
print(ctx)
# Pre-loading the model on startup and setting autotune to 0 for speed
#detector = gluoncv.model_zoo.get_model('yolo3_mobilenet1.0_coco', pretrained=True, ctx=ctx)
#detector = gluoncv.model_zoo.get_model('yolo3_mobilenet1.0_coco', pretrained=True,ctx=ctx)
os.environ["MXNET_CUDNN_AUTOTUNE_DEFAULT"] = "0"

# ------------------------------------------------------------ #
# Hosting methods                                              #
# ------------------------------------------------------------ #

def model_fn(model_dir):
    """
    Load the GluonCV model. Called once when hosting service starts. Model was downloaded on startup.
    :param: model_dir The directory where model files are stored.
    :return: a model (in this case a Gluon network)
    """       
    #net = gluoncv.model_zoo.get_model('faster_rcnn_fpn_resnet101_v1d_coco', pretrained=True, ctx=ctx)
    print("&&&&&")
    ctx = mx.gpu(0) if mx.context.num_gpus() > 0 else mx.cpu()
    print(ctx)
    #detector = gluoncv.model_zoo.get_model('yolo3_mobilenet1.0_coco', pretrained=True,ctx=ctx)
    detector = gluoncv.model_zoo.get_model('yolo3_mobilenet1.0_coco', pretrained=True)
    return detector


def transform_fn(detector, payload, content_type, accept):
    """
    Transform a request using the GluonCV model. Called once per request.
    :param detector: The GluonCV model.
    :param payload: The request payload.
    :param content_type: The input content type.
    :param accept: The (desired) content type.
    :return: response output.
    """
    print("transform yolo3")
    ctx = mx.gpu(0) if mx.context.num_gpus() > 0 else mx.cpu()
    print(ctx)
    if content_type != 'application/x-image':
        raise RuntimeError('Content type must be application/x-image')

    f = io.BytesIO(payload)
    
    # Load image and convert to RGB space
    image = PIL.Image.open(f).convert('RGB')
    image.save('tmp.jpg')
    
    # This section is from the GluonCV tutorial for Yolo3 person detection to be used prior to pose estimation
    detector.reset_class(["person"], reuse_weights=['person'])
    #im_fname = utils.download('https://github.com/dmlc/web-data/blob/master/' +'gluoncv/pose/soccer.png?raw=true',path='soccer.png')
    im_fname = 'tmp.jpg'
    x, img = gluoncv.data.transforms.presets.yolo.load_test(im_fname)
    print('Shape of pre-processed image:', x.shape)
    class_IDs, scores, bounding_boxs = detector(x)
    pose_input, upscale_bbox = detector_to_alpha_pose(img, class_IDs, scores, bounding_boxs)
   
    # Format the response for being passed back from the endpoint
    response = {}
    #class_IDs, scores, bounding_boxs
    response['class_IDs'] = class_IDs[0].asnumpy().tolist()
    response['scores'] = scores[0].asnumpy().tolist()
    response['bounding_boxs'] = bounding_boxs[0].asnumpy().tolist()
    response['pose_input'] = pose_input[0].asnumpy().tolist()
    response['upscale_bbox'] = upscale_bbox[0].tolist()
    print("done")
    output = json.dumps(response)
    print("dumped json to output")
    #print(output)
    return output

